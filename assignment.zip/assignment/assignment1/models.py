from django.db import models

# Create your models here.

class mumbai:
    name : str
    page : str
    price : int
   

class assignment(models.Model):
    name = models.CharField(max_length=100)
   
    page = models.TextField()
    price = models.IntegerField()
    
    
