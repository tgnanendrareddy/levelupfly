
from docx import Document


def fun():
  
  hello = open('pageeea.docx','w')
  print(hello)

fun()
