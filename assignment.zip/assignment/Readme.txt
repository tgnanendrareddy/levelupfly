yeh hii 
this is Gnanendra 
hereby i convey to you that , 
STATUS : Everything Statistically completed , wanna make it Dynamic 


simple Procedure:
1.Created local project
2.created localhost app
3.created super user where user can do typing text page 
4.created database in postgresql name of Mumbai
5.linked eachother with the help of ORM Procedure (psycopg2 package)
6.updated with engine, name, user, password, host in settings.py
7.created models with DJANGO MODEL FIELDS 
8.had linked the app in INSTALLED_Apps in settings.py
9.have done migrations with makemigrations with pillow package 
10.migrations succefully completed and everything worked fine 
11. help of LOCALHOST:8000/ADMIN/ i just pushed the data form admin page with the help of save 
12. data had stored directly to postgresql table 
13. created application with HTML,CSS for layout for better looking 
14. everything has working fine till this point 
15. created all page1, page2, page3, page4 linked all eachother

STATUS: Everything Completed s

Referance: ORM Mapping steps
step-1 : Go to assignment - settings.py check [installed apps , db connections, templates linkings]
step-2 : Go to assignment - urls.py 
step-3 : Go to Mumbai app - urls.py
step-4 : Go to Mumbai app - views.py
step-5 : Go to Templates - page1
step-6 : Go to Templates - page2
step-7 : Go to Templates - page3
step-8 : Go to Templates - page4

Discription:

When user click on Page1 its shows please click on Page2
When user click on Page2 its shows please click on Page3
When user click on Page3 its shows please click on page4
When user click on Page4 its shows one form to Fill his/her details 

after filling the details there is an option to play with word document where user wants to add and edit data in word document

once click on submit all data that is user details and word data will be stored on postgresql rows/columns

NOTE: For more understanding i had mentioned images of procedure , 
      please go with the images with serial number so that you can understand clear


